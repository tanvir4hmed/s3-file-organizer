import json
import boto3
import os
from datetime import datetime

s3 = boto3.client('s3')

def lambda_handler(event, context):
    # Retrieve bucket name from environment variable
    bucket_name = os.environ['BUCKET_NAME']  # Updated to match the environment variable set in Terraform
    try:
        # Process each record in the event
        for record in event['Records']:
            key = record['s3']['object']['key']
            
            # Get current timestamp for folder structure
            current_time = datetime.now()
            year = current_time.strftime('%Y')
            month = current_time.strftime('%m')
            day = current_time.strftime('%d')
            
            # Define the new file path
            new_key = f"{year}/{month}/{day}/{os.path.basename(key)}"  # Use os.path.basename for clarity
            
            # Move the file to the new folder structure
            s3.copy_object(Bucket=bucket_name, CopySource={'Bucket': bucket_name, 'Key': key}, Key=new_key)
            s3.delete_object(Bucket=bucket_name, Key=key)
        
        return {
            'statusCode': 200,
            'body': json.dumps('Files organized successfully!')
        }
    
    except Exception as e:
        # Log the error and return a failure response
        print(f"Error processing files: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps('Error organizing files.')
        }
